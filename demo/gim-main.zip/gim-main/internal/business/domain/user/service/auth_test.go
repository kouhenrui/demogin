package service

import (
	"testing"
)

func TestAuthService_SignIn(t *testing.T) {
}

func TestAuthService_Auth(t *testing.T) {

}
