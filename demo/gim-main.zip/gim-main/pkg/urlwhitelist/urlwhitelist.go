package urlwhitelist

var Business = map[string]int{
	"/pb.BusinessExt/SignIn": 0,
}

var Logic = map[string]int{
	"/pb.LogicExt/RegisterDevice": 0,
}
